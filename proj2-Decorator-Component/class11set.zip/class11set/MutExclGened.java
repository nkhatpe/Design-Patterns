package class11set;

public enum MutExclGened implements GenEd {
	A, D, G, H, N, USD 
}
