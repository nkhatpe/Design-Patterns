package class11set;

public enum StackableGened implements GenEd {
	C, O, J, T, I, Y, S, B, M, W
	// W is Harpur Writing but coded with the GenEds
}
