package class11set;

import java.util.Set;
public abstract class GenEdAbs {
	public abstract Set<Set<GenEd>> getAllMutexGeneds();
	public abstract Set<GenEd> getAllStackableGeneds();
}
