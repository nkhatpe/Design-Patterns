package class11set;

import java.util.HashSet;
import java.util.Set;

public class Student extends GenEdAbs {
	private String bNumber;
	private String name;
	private String email;
	public Student(String bNumberIn, String nameIn, String emailIn) {
		bNumber = bNumberIn;
		name = nameIn;
		email = emailIn;
	}
	public Set<Set<GenEd>> getAllMutexGeneds() {
		var temp = new HashSet<Set<GenEd>>();
		temp.add(new HashSet<>());
		return temp;
	}

	@Override
	public Set<GenEd> getAllStackableGeneds() {
		return new HashSet<GenEd>();
	}
	
}
