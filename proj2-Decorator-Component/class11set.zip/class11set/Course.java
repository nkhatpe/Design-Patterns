package class11set;

import java.util.HashSet;
import java.util.Set;

public class Course extends Decorator {
	private String course;
	private Set<GenEd> language;
	private Set<GenEd> stackable;
	private Set<GenEd> exclusive;

	public Course(GenEdAbs delegate, String courseIn, Set<GenEd> langIn, 
			Set<GenEd> stackIn, Set<GenEd> exclIn) {
		super(delegate);
		course = courseIn;
		language = langIn;
		if(language == null) language = new HashSet<>();
		stackable = stackIn;
		if(stackable == null) stackable = new HashSet<>();
		exclusive = exclIn;
		if(exclusive == null) exclusive = new HashSet<>();
	}

	@Override
	public Set<GenEd> getMutExclGeneds() {
		return exclusive;
	}

	@Override
	public Set<GenEd> getStackGeneds() {
		return stackable;
	}

	@Override
	public Set<GenEd> getLanguageGeneds() {
		return language;
	}	
}
