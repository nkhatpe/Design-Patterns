package class11set;

import java.util.HashSet;

public class Tester {

	public static void main(String[] args) {
		Student st = new Student("B12345678", "A Student", "astudent@binghamton.edu");
		System.out.println(st.getAllMutexGeneds());		
		System.out.println(st.getAllStackableGeneds());		
		var mexSet = new HashSet<GenEd>();
		mexSet.add(MutExclGened.N);
		mexSet.add(MutExclGened.USD);
		Decorator course = new Course(st, "GEOG 103", null, null, mexSet);
		System.out.println(course.getAllMutexGeneds());		
		System.out.println(course.getAllStackableGeneds());		

		mexSet = new HashSet<GenEd>();
		mexSet.add(MutExclGened.G);
		mexSet.add(MutExclGened.N);
		mexSet.add(MutExclGened.USD);
		var stkSet = new HashSet<GenEd>();
		stkSet.add(StackableGened.I);
		stkSet.add(StackableGened.T);
		stkSet.add(StackableGened.W);
		course = new Course(course, "HIST 103A", null, stkSet, mexSet);
		System.out.println(course.getAllMutexGeneds());		
		System.out.println(course.getAllStackableGeneds());		
		stkSet = new HashSet<GenEd>();
		stkSet.add(StackableGened.M);
		course = new Course(course, "MATH 147", null, stkSet, null);
		System.out.println(course.getAllMutexGeneds());		
		System.out.println(course.getAllStackableGeneds());		
		mexSet = new HashSet<GenEd>();
		mexSet.add(MutExclGened.H);
		stkSet = new HashSet<GenEd>();
		stkSet.add(StackableGened.C);
		course = new Course(course, "COLI 281E", null, stkSet, mexSet);
		System.out.println(course.getAllMutexGeneds());		
		System.out.println(course.getAllStackableGeneds());		
		mexSet = new HashSet<GenEd>();
		mexSet.add(MutExclGened.A);
		mexSet.add(MutExclGened.G);
		stkSet = new HashSet<GenEd>();
		stkSet.add(StackableGened.I);
		stkSet.add(StackableGened.O);
		stkSet.add(StackableGened.T);
		stkSet.add(StackableGened.W);
		course = new Course(course, "AFST 383P", null, stkSet, mexSet);
		System.out.println(course.getAllMutexGeneds());		
		System.out.println(course.getAllStackableGeneds());		
	}

}
