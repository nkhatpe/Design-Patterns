package class11set;

import java.util.Objects;

public class WorldLangGened implements GenEd {
	public static enum Level {WL1, WL2, WL3};
	public static enum BUlang {A("Arabic"), C("Chinese"), 
		F("French"), G("German"), I("Italian"), 
		J("Japanese"), K("Korean"), R("Russian"); 
		String name;
		BUlang(String nameIn) {name = nameIn;}
		public String toString() {return name;}
	};
	private BUlang lang;
	private Level level;
	WorldLangGened(BUlang langIn, Level levelIn) {
		lang = langIn;
		level = levelIn;
	}
	@Override
	public int hashCode() {
		return Objects.hash(lang, level);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		WorldLangGened other = (WorldLangGened) obj;
		return lang == other.lang && level == other.level;
	}
}
