package class11set;

public interface GenEd {

}
