package class11set;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public abstract class Decorator extends GenEdAbs {
	private GenEdAbs delegate;
	public Decorator(GenEdAbs delegate) {
		this.delegate = delegate;
	}	
	public abstract Set<GenEd> getMutExclGeneds();
	public abstract Set<GenEd> getStackGeneds();
	public abstract Set<GenEd> getLanguageGeneds();

	public Set<Set<GenEd>> getAllMutexGeneds() {
		var tempIn = delegate.getAllMutexGeneds();
		if(getMutExclGeneds().isEmpty()) return tempIn;
		var tempOut = new HashSet<Set<GenEd>>();
		int max = 0;
		for(Set<GenEd> set : tempIn) {
			for(GenEd g : getMutExclGeneds()) {
				HashSet<GenEd> temp = 
						(HashSet<GenEd>)((HashSet<GenEd>)set).clone();
				temp.add(g);
				max = Math.max(max, temp.size());
				tempOut.add(temp);
			}
		}
		// clean up repeats
		Iterator<Set<GenEd>> iter = tempOut.iterator();
		while(iter.hasNext()) {
			var temp = iter.next();
			if(temp.size() < max) iter.remove();
		}
		return tempOut;
	}

	public Set<GenEd> getAllStackableGeneds() {
		var temp = delegate.getAllStackableGeneds();
		for(GenEd g : getStackGeneds()) {
			temp.add(g);
		}
		return temp;
	}
}
